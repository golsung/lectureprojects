package com.insang.kdtexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KdtexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
