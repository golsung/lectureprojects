package com.insang.kdtexample.domain;

public enum Grade {
	A, B, C, D, F;
}
