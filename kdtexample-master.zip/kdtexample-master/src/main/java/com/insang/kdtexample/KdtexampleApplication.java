package com.insang.kdtexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KdtexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(KdtexampleApplication.class, args);
	}

}
