public class InvalidRangeException extends RuntimeException {
}
