public enum BurgerKind {
    BEEF, SHRIMP, CHICKEN
}
