public interface PriceManager {
    int getPrice(String id);
    boolean isTwoPlusOneApplicable(String s);
}
