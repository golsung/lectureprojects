public class Doc {
    public void say(String s) {
        System.out.println(s);
    }
}
