class VerifyEx {
    private Doc doc;
    public void doIt(String str) {
        if (str == "Hello") {
            doc.say("Hello World!");
            doc.say("Hello World!");
        } else doc.say("Good Bye!");
    }
}
