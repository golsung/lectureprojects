public interface PriceManager {
    int getPrice(String id);
}
